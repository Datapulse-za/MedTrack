import React, { useMemo } from "react";

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function formatDate(dateStr) {
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

export default function CaregiverView({ medications, logs, statusByMedId, adherenceRate30, streak }) {
  const recentMissed = useMemo(() => {
    return logs
      .filter((l) => l.status === "missed")
      .slice()
      .sort((a, b) => (a.date < b.date ? 1 : -1))
      .slice(0, 8);
  }, [logs]);

  const pendingToday = medications.filter((m) => !statusByMedId[m.id]);
  const missedToday = medications.filter((m) => statusByMedId[m.id] === "missed");

  return (
    <div className="space-y-6">
      <div className="bg-teal-800 text-white rounded-2xl p-6">
        <p className="text-xs uppercase tracking-wide text-teal-200 font-semibold mb-1">Caregiver view</p>
        <h2 className="text-xl font-bold mb-2">Demo Patient's medication overview</h2>
        <p className="text-sm text-teal-100 leading-relaxed max-w-xl">
          A caregiver can check in on adherence at a glance, without needing to track every dose
          themselves — the same visibility gap general reminder apps and pill organisers leave
          unfilled.
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">30-day adherence</p>
          <p className={`text-3xl font-bold ${adherenceRate30 >= 80 ? "text-green-600" : adherenceRate30 >= 50 ? "text-amber-600" : "text-red-600"}`}>
            {adherenceRate30}%
          </p>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Current streak</p>
          <p className="text-3xl font-bold text-gold">{streak}</p>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Missed today</p>
          <p className={`text-3xl font-bold ${missedToday.length === 0 ? "text-green-600" : "text-red-600"}`}>
            {missedToday.length}
          </p>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Still pending today</p>
          <p className={`text-3xl font-bold ${pendingToday.length === 0 ? "text-green-600" : "text-amber-600"}`}>
            {pendingToday.length}
          </p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Today's status by medication</h3>
        {medications.length === 0 ? (
          <p className="text-sm text-gray-400 text-center py-6">No medications being tracked yet.</p>
        ) : (
          <ul className="divide-y divide-gray-100">
            {medications.map((m) => {
              const status = statusByMedId[m.id];
              return (
                <li key={m.id} className="py-2.5 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{m.name}</p>
                    <p className="text-xs text-gray-500">Scheduled {m.time}</p>
                  </div>
                  <span
                    className={`text-xs font-bold uppercase tracking-wide px-2.5 py-1 rounded-full shrink-0 ${
                      status === "taken"
                        ? "bg-green-100 text-green-700"
                        : status === "missed"
                        ? "bg-red-100 text-red-700"
                        : "bg-amber-100 text-amber-700"
                    }`}
                  >
                    {status === "taken" ? "Taken" : status === "missed" ? "Missed" : "Pending"}
                  </span>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-1">Recent missed doses</h3>
        <p className="text-sm text-gray-400 mb-4">The last few doses recorded as missed, most recent first.</p>
        {recentMissed.length === 0 ? (
          <p className="text-sm text-green-700 text-center py-6">No missed doses recorded — good adherence.</p>
        ) : (
          <ul className="divide-y divide-gray-100">
            {recentMissed.map((log, i) => (
              <li key={i} className="py-2.5 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">{log.medication}</p>
                  <p className="text-xs text-gray-500">Scheduled {log.scheduledTime}</p>
                </div>
                <span className="text-xs text-red-600 font-medium shrink-0">{formatDate(log.date)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
