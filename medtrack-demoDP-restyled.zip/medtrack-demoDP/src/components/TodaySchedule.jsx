import React from "react";

function isPast(time) {
  const [h, m] = time.split(":").map(Number);
  const now = new Date();
  const t = new Date();
  t.setHours(h, m, 0, 0);
  return t.getTime() < now.getTime();
}

export default function TodaySchedule({ medications, statusByMedId, onMarkTaken, onMarkMissed }) {
  const sorted = [...medications].sort((a, b) => a.time.localeCompare(b.time));

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-gray-900">Today's schedule</h2>
        <span className="text-xs text-gray-400">
          {new Date().toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" })}
        </span>
      </div>

      {sorted.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-sm text-gray-400">Nothing scheduled yet.</p>
          <p className="text-xs text-gray-400 mt-1">Add a medication to see it here.</p>
        </div>
      ) : (
        <ul className="space-y-2">
          {sorted.map((m) => {
            const status = statusByMedId[m.id]; // "taken" | "missed" | undefined
            const overdue = !status && isPast(m.time);
            return (
              <li
                key={m.id}
                className={`flex items-center justify-between gap-3 rounded-lg px-4 py-3 border transition-colors ${
                  status === "taken"
                    ? "bg-green-50 border-green-100"
                    : status === "missed"
                    ? "bg-red-50 border-red-100"
                    : overdue
                    ? "bg-amber-50 border-amber-100"
                    : "bg-gray-50 border-gray-100"
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <button
                    onClick={() => !status && onMarkTaken(m)}
                    disabled={!!status}
                    className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors ${
                      status === "taken"
                        ? "bg-green-500 border-green-500"
                        : status === "missed"
                        ? "bg-red-400 border-red-400"
                        : "border-gray-300 hover:border-teal-600 cursor-pointer"
                    }`}
                    aria-label={status === "taken" ? "Taken" : status === "missed" ? "Missed" : `Mark ${m.name} as taken`}
                  >
                    {status === "taken" && (
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                        <path d="M4 12l5 5L20 6" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    )}
                    {status === "missed" && (
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none">
                        <path d="M6 6l12 12M18 6L6 18" stroke="white" strokeWidth="3" strokeLinecap="round" />
                      </svg>
                    )}
                  </button>
                  <div className="min-w-0">
                    <p className={`text-sm font-medium truncate ${
                      status === "taken" ? "text-green-800 line-through" : status === "missed" ? "text-red-700" : "text-gray-900"
                    }`}>
                      {m.name}{m.dosage && <span className="text-gray-400 font-normal"> · {m.dosage}</span>}
                    </p>
                    <p className={`text-xs ${overdue ? "text-amber-700 font-medium" : status === "missed" ? "text-red-600" : "text-gray-500"}`}>
                      {m.time}{overdue && " · due now"}{status === "missed" && " · missed"}
                    </p>
                    {m.instructions && !status && (
                      <p className="text-xs text-teal-700 mt-0.5">{m.instructions}</p>
                    )}
                  </div>
                </div>
                {!status && (
                  <div className="flex items-center gap-3 shrink-0">
                    <button
                      onClick={() => onMarkMissed(m)}
                      className="text-xs font-semibold text-gray-400 hover:text-red-600 hover:underline whitespace-nowrap"
                    >
                      Missed
                    </button>
                    <button
                      onClick={() => onMarkTaken(m)}
                      className="text-xs font-semibold text-teal-700 hover:underline whitespace-nowrap"
                    >
                      Mark taken
                    </button>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
