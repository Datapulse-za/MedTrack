import React, { useState } from "react";
import logo from "../assets/medtrack-logo-trimmed.png";

// ---------------------------------------------------------------------------
// DEMO LOGIN — HARDCODED CREDENTIALS
// This app has no real authentication backend. These are the only credentials
// that will work, so you (the developer) can hand them to anyone demoing the app.
//
//   Username: demo
//   Password: medtrack2026
//
// Do NOT reuse this pattern in production — this exists only so the demo
// doesn't need a real auth server.
// ---------------------------------------------------------------------------
const DEMO_USERNAME = "demo";
const DEMO_PASSWORD = "medtrack2026";

export default function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    if (username === DEMO_USERNAME && password === DEMO_PASSWORD) {
      setError("");
      onLogin();
    } else {
      setError("Incorrect username or password.");
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-800 via-teal-700 to-teal-600 px-4 relative overflow-hidden">
      <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-white/5 pointer-events-none" />
      <div className="absolute -bottom-32 -left-16 w-80 h-80 rounded-full bg-amber2/10 pointer-events-none" />

      <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl p-8 animate-fade-in relative">
        <div className="flex flex-col items-center mb-6">
          <img src={logo} alt="MedTrack logo" className="w-24 h-24 object-contain mb-2" />
          <h1 className="text-2xl font-bold text-gray-900">MedTrack</h1>
          <p className="text-sm text-gray-500 mt-1">Sign in to your account</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
              placeholder="demo"
              autoComplete="username"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
              placeholder="••••••••"
              autoComplete="current-password"
            />
          </div>

          {error && <p className="text-sm text-red-600">{error}</p>}

          <button
            type="submit"
            className="w-full bg-teal-700 text-white font-semibold py-2.5 rounded-lg hover:bg-teal-800 transition-colors"
          >
            Sign in
          </button>
        </form>

        <div className="mt-6 pt-5 border-t border-gray-100 text-center">
          <p className="text-xs text-gray-400">Demo credentials</p>
          <p className="text-xs text-gray-500 mt-1 font-mono">demo / medtrack2026</p>
        </div>
      </div>
    </div>
  );
}
