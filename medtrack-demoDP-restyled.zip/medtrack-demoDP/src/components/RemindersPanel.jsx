import React from "react";

function formatTime(date) {
  if (!date) return "—";
  return new Date(date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export default function RemindersPanel({ permission, onRequestPermission, reminders, onTestNotification }) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
      <h2 className="text-lg font-bold text-gray-900 mb-4">Notifications</h2>

      {permission !== "granted" && (
        <div className="mb-4 bg-amber-50 border border-amber-100 rounded-lg p-3">
          <p className="text-sm text-amber-800 mb-2">
            Enable notifications to receive dose and pre-dose reminders.
          </p>
          <button
            onClick={onRequestPermission}
            className="text-sm font-semibold bg-amber-500 text-white px-3 py-1.5 rounded-lg hover:bg-amber-600 transition-colors"
          >
            Enable notifications
          </button>
        </div>
      )}

      {permission === "granted" && (
        <p className="text-sm text-green-700 mb-4">Notifications are enabled.</p>
      )}

      {reminders.length === 0 ? (
        <p className="text-sm text-gray-400">No upcoming reminders yet — log a medication to schedule one.</p>
      ) : (
        <ul className="space-y-3">
          {reminders.map((r, i) => (
            <li key={i} className="border border-gray-100 rounded-lg p-3">
              <p className="font-medium text-gray-900 text-sm">{r.medication}</p>
              <p className="text-xs text-gray-500 mt-0.5">
                Pre-reminder at {formatTime(r.preReminderAt)} · Dose reminder at {formatTime(r.nextDoseAt)}
              </p>
              <button
                onClick={() => onTestNotification(r.medication)}
                className="text-xs font-semibold text-teal-700 hover:underline mt-1"
              >
                Send test notification now
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
