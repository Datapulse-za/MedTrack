import React from "react";

function StatCard({ label, value, sublabel, accent }) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
      <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">{label}</p>
      <p className={`text-3xl font-bold ${accent || "text-gray-900"}`}>{value}</p>
      {sublabel && <p className="text-xs text-gray-400 mt-1">{sublabel}</p>}
    </div>
  );
}

export default function StatsCards({ medications, takenTodayCount, adherenceRate30, missedCount30, streak }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
      <StatCard
        label="Today"
        value={`${takenTodayCount}/${medications.length}`}
        sublabel="doses taken"
        accent="text-teal-700"
      />
      <StatCard
        label="Adherence"
        value={`${adherenceRate30}%`}
        sublabel="last 30 days"
        accent={adherenceRate30 >= 80 ? "text-green-600" : adherenceRate30 >= 50 ? "text-amber-600" : "text-red-600"}
      />
      <StatCard
        label="Missed"
        value={missedCount30}
        sublabel="last 30 days"
        accent={missedCount30 === 0 ? "text-green-600" : "text-red-600"}
      />
      <StatCard
        label="Streak"
        value={streak}
        sublabel={streak === 1 ? "day in a row" : "days in a row"}
        accent="text-gold"
      />
      <StatCard
        label="Medications"
        value={medications.length}
        sublabel="being tracked"
      />
    </div>
  );
}
