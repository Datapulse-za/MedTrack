import React from "react";

export default function Leaflet({ info, onClose }) {
  if (!info) return null;

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center px-4 z-50">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-6 animate-slide-in max-h-[85vh] overflow-y-auto">
        <div className="flex items-start justify-between mb-4">
          <div>
            <p className="text-xs font-semibold text-teal-700 uppercase tracking-wide">Medication info</p>
            <h2 className="text-xl font-bold text-gray-900">{info.displayName}</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-700 text-xl leading-none"
            aria-label="Close"
          >
            ×
          </button>
        </div>

        <section className="mb-5">
          <h3 className="text-sm font-semibold text-gray-800 mb-2 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 inline-block" />
            Benefits
          </h3>
          <ul className="space-y-1.5">
            {info.benefits.map((b, i) => (
              <li key={i} className="text-sm text-gray-600 leading-snug pl-4 relative">
                <span className="absolute left-0 text-green-500">•</span>
                {b}
              </li>
            ))}
          </ul>
        </section>

        <section className="mb-5">
          <h3 className="text-sm font-semibold text-gray-800 mb-2 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
            Possible side effects
          </h3>
          <ul className="space-y-1.5">
            {info.sideEffects.map((s, i) => (
              <li key={i} className="text-sm text-gray-600 leading-snug pl-4 relative">
                <span className="absolute left-0 text-amber-500">•</span>
                {s}
              </li>
            ))}
          </ul>
        </section>

        <section className="bg-red-50 border border-red-100 rounded-lg p-3 mb-5">
          <h3 className="text-sm font-semibold text-red-700 mb-1">Seek medical help if:</h3>
          <p className="text-sm text-red-700 leading-snug">{info.seekHelpIf}</p>
        </section>

        <p className="text-[11px] text-gray-400 leading-snug mb-4">
          This information is for general awareness only and is not a substitute for advice from
          your doctor or pharmacist. Demo data — not a verified medical source.
        </p>

        <button
          onClick={onClose}
          className="w-full bg-teal-700 text-white font-semibold py-2.5 rounded-lg hover:bg-teal-800 transition-colors"
        >
          Got it
        </button>
      </div>
    </div>
  );
}
