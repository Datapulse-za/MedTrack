import React, { useState } from "react";

const COLORS = ["bg-teal-100 text-teal-700", "bg-amber-100 text-amber-700", "bg-blue-100 text-blue-700", "bg-rose-100 text-rose-700", "bg-violet-100 text-violet-700"];

export default function MedicationsManager({ medications, onAdd, onRemove }) {
  const [name, setName] = useState("");
  const [dosage, setDosage] = useState("");
  const [time, setTime] = useState("08:00");
  const [instructions, setInstructions] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    if (!name.trim()) return;
    onAdd({
      id: crypto.randomUUID(),
      name: name.trim(),
      dosage: dosage.trim(),
      time,
      instructions: instructions.trim(),
    });
    setName("");
    setDosage("");
    setTime("08:00");
    setInstructions("");
  }

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
      <h2 className="text-lg font-bold text-gray-900 mb-1">Your medications</h2>
      <p className="text-sm text-gray-400 mb-4">
        Add each medication once, with any instructions from your prescription — it'll appear on
        your daily schedule automatically.
      </p>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-5">
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Medication name"
          className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
          required
        />
        <input
          type="text"
          value={dosage}
          onChange={(e) => setDosage(e.target.value)}
          placeholder="Dosage (e.g. 500mg)"
          className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
        />
        <input
          type="text"
          value={instructions}
          onChange={(e) => setInstructions(e.target.value)}
          placeholder="Instructions (e.g. take with food)"
          className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-600 sm:col-span-2"
        />
        <div className="flex gap-2 sm:col-span-2">
          <input
            type="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
            required
          />
          <button
            type="submit"
            className="flex-1 bg-teal-700 text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap"
          >
            Add medication
          </button>
        </div>
      </form>

      {medications.length === 0 ? (
        <p className="text-sm text-gray-400 text-center py-6">No medications added yet — add your first one above.</p>
      ) : (
        <ul className="space-y-2">
          {medications.map((m, i) => (
            <li
              key={m.id}
              className="flex items-start justify-between gap-3 border border-gray-100 rounded-lg px-4 py-3"
            >
              <div className="flex items-start gap-3 min-w-0">
                <span className={`w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${COLORS[i % COLORS.length]}`}>
                  {m.name.slice(0, 2).toUpperCase()}
                </span>
                <div className="min-w-0">
                  <p className="font-medium text-gray-900 text-sm truncate">
                    {m.name}{m.dosage && <span className="text-gray-400 font-normal"> · {m.dosage}</span>}
                  </p>
                  <p className="text-xs text-gray-500">Daily at {m.time}</p>
                  {m.instructions && (
                    <p className="text-xs text-teal-700 mt-0.5">{m.instructions}</p>
                  )}
                </div>
              </div>
              <button
                onClick={() => onRemove(m.id)}
                className="text-gray-300 hover:text-red-500 text-lg leading-none px-1 shrink-0"
                aria-label={`Remove ${m.name}`}
              >
                ×
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
