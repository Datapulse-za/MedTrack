import React, { useState } from "react";

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}
function nowTimeStr() {
  return new Date().toTimeString().slice(0, 5);
}

export default function ManualLogForm({ medications, onLog }) {
  const [medicationId, setMedicationId] = useState(medications[0]?.id || "");
  const [date, setDate] = useState(todayStr());
  const [takenTime, setTakenTime] = useState(nowTimeStr());
  const [status, setStatus] = useState("taken");

  React.useEffect(() => {
    if (!medicationId && medications.length > 0) setMedicationId(medications[0].id);
  }, [medications]);

  if (medications.length === 0) {
    return (
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 text-center">
        <p className="text-sm text-gray-400">
          Add a medication first (Medications tab) before logging a dose.
        </p>
      </div>
    );
  }

  function handleSubmit(e) {
    e.preventDefault();
    const med = medications.find((m) => m.id === medicationId);
    if (!med) return;
    onLog({
      medicationId: med.id,
      medication: med.name,
      dosage: med.dosage,
      scheduledTime: med.time,
      takenTime: status === "missed" ? "" : takenTime,
      date,
      status,
      loggedAt: new Date().toISOString(),
    });
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
      <h2 className="text-lg font-bold text-gray-900 mb-1">Log a dose</h2>
      <p className="text-sm text-gray-400 mb-4">
        Use this to log today's dose, backfill an earlier one, or record a dose you missed.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-[1.2fr_1fr_1fr_1fr] gap-2 items-end mb-3">
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">Medication</label>
          <select
            value={medicationId}
            onChange={(e) => setMedicationId(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
          >
            {medications.map((m) => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">Date</label>
          <input
            type="date"
            value={date}
            max={todayStr()}
            onChange={(e) => setDate(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">Time taken</label>
          <input
            type="time"
            value={takenTime}
            onChange={(e) => setTakenTime(e.target.value)}
            disabled={status === "missed"}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-600 disabled:bg-gray-50 disabled:text-gray-400"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">Status</label>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
          >
            <option value="taken">Taken</option>
            <option value="missed">Missed</option>
          </select>
        </div>
      </div>

      <button
        type="submit"
        className={`w-full text-white text-sm font-semibold px-4 py-2.5 rounded-lg transition-colors ${
          status === "missed" ? "bg-red-500 hover:bg-red-600" : "bg-teal-700 hover:bg-teal-800"
        }`}
      >
        {status === "missed" ? "Log as missed" : "Log as taken"}
      </button>
    </form>
  );
}
