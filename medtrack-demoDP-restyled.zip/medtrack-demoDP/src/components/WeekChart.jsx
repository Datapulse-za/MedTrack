import React from "react";

export default function WeekChart({ logs, medications }) {
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(d);
  }

  const scheduledPerDay = medications.length || 1;

  const bars = days.map((d, idx) => {
    const dateStr = d.toISOString().slice(0, 10);
    const takenCount = new Set(
      logs.filter((l) => l.date === dateStr && l.status === "taken").map((l) => l.medicationId).filter(Boolean)
    ).size;
    const pct = Math.min(100, Math.round((takenCount / scheduledPerDay) * 100));
    return { label: d.toLocaleDateString(undefined, { weekday: "narrow" }), pct, isToday: idx === days.length - 1 };
  });

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
      <h2 className="text-lg font-bold text-gray-900 mb-1">This week</h2>
      <p className="text-sm text-gray-400 mb-5">Doses taken vs. scheduled, per day.</p>
      <div className="flex items-end justify-between gap-2 h-32">
        {bars.map((b, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-2">
            <div className="w-full h-24 bg-gray-100 rounded-md flex items-end overflow-hidden">
              <div
                className={`w-full rounded-md transition-all ${b.pct >= 80 ? "bg-green-500" : b.pct >= 40 ? "bg-amber-400" : b.pct > 0 ? "bg-red-400" : "bg-gray-200"}`}
                style={{ height: `${Math.max(4, b.pct)}%` }}
              />
            </div>
            <span className={`text-xs ${b.isToday ? "font-bold text-teal-700" : "text-gray-400"}`}>{b.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
