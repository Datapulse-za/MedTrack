import React, { useMemo, useState } from "react";

function formatDate(dateStr) {
  const d = new Date(dateStr + "T00:00:00");
  const today = new Date().toISOString().slice(0, 10);
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  if (dateStr === today) return "Today";
  if (dateStr === yesterday) return "Yesterday";
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

export default function LogHistory({ logs, onViewLeaflet }) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    if (!query.trim()) return logs;
    const q = query.trim().toLowerCase();
    return logs.filter((l) => l.medication.toLowerCase().includes(q));
  }, [logs, query]);

  const grouped = useMemo(() => {
    const groups = {};
    filtered
      .slice()
      .sort((a, b) => (a.date + a.takenTime < b.date + b.takenTime ? 1 : -1))
      .forEach((log) => {
        const key = log.date || "Unknown date";
        if (!groups[key]) groups[key] = [];
        groups[key].push(log);
      });
    return Object.entries(groups);
  }, [filtered]);

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-4 gap-3">
        <h2 className="text-lg font-bold text-gray-900">History</h2>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search medication…"
          className="text-sm px-3 py-1.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600 w-40 sm:w-56"
        />
      </div>

      {logs.length === 0 ? (
        <div className="text-center py-10">
          <div className="w-12 h-12 rounded-full bg-teal-50 flex items-center justify-center mx-auto mb-3">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M12 8v4l3 3" stroke="#0f6d64" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="12" cy="12" r="9" stroke="#0f6d64" strokeWidth="2"/>
            </svg>
          </div>
          <p className="text-sm text-gray-500 font-medium">No doses logged yet</p>
          <p className="text-xs text-gray-400 mt-1">Logged doses will show up here, grouped by day.</p>
        </div>
      ) : filtered.length === 0 ? (
        <p className="text-sm text-gray-400 text-center py-8">No results for "{query}".</p>
      ) : (
        <div className="space-y-5 max-h-[520px] overflow-y-auto pr-1">
          {grouped.map(([date, entries]) => (
            <div key={date}>
              <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2">
                {formatDate(date)}
              </p>
              <ul className="divide-y divide-gray-100">
                {entries.map((log, i) => (
                  <li key={i} className="py-2.5 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-medium text-gray-900 text-sm truncate flex items-center gap-2">
                        {log.medication}
                        {log.dosage && <span className="text-gray-400 font-normal">· {log.dosage}</span>}
                        {log.status === "missed" ? (
                          <span className="text-[10px] font-bold uppercase tracking-wide bg-red-100 text-red-700 px-1.5 py-0.5 rounded">Missed</span>
                        ) : (
                          <span className="text-[10px] font-bold uppercase tracking-wide bg-green-100 text-green-700 px-1.5 py-0.5 rounded">Taken</span>
                        )}
                      </p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        Scheduled {log.scheduledTime}
                        {log.status !== "missed" && ` · Taken ${log.takenTime}`}
                      </p>
                    </div>
                    <button
                      onClick={() => onViewLeaflet(log.medication)}
                      className="text-xs font-semibold text-teal-700 hover:underline whitespace-nowrap shrink-0"
                    >
                      Info
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
