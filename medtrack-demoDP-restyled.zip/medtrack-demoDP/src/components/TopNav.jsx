import React from "react";
import logo from "../assets/medtrack-logo-trimmed.png";

const TABS = [
  { id: "dashboard", label: "Dashboard" },
  { id: "medications", label: "Medications" },
  { id: "history", label: "History" },
  { id: "caregiver", label: "Caregiver view" },
];

export default function TopNav({ activeTab, onTabChange, onSignOut, alertCount }) {
  return (
    <header className="bg-teal-800 text-white sticky top-0 z-40 shadow-md">
      <div className="max-w-5xl mx-auto px-4 pt-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <img src={logo} alt="MedTrack" className="w-9 h-9 rounded-lg object-contain bg-white p-0.5" />
          <span className="font-bold text-lg">MedTrack</span>
        </div>
        <div className="flex items-center gap-4">
          {alertCount > 0 && (
            <span className="hidden sm:flex items-center gap-1.5 text-xs bg-white/10 px-2.5 py-1 rounded-full text-amber-200">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-300" />
              {alertCount} due
            </span>
          )}
          <button onClick={onSignOut} className="text-sm text-white/70 hover:text-white">
            Sign out
          </button>
        </div>
      </div>
      <nav className="max-w-5xl mx-auto px-4 mt-4 flex gap-1">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`px-4 py-2.5 text-sm font-semibold rounded-t-lg transition-colors ${
              activeTab === tab.id
                ? "bg-cream text-teal-800"
                : "text-white/70 hover:text-white hover:bg-white/5"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </nav>
    </header>
  );
}
