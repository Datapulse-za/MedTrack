// Local reference data for demo purposes only.
// This is NOT a medical database — in a production build this would call
// a licensed drug-information API (e.g. openFDA, a pharmacy API) instead
// of hardcoded text. Keeping it local here so the demo works fully offline.

export const MEDICATION_LIBRARY = {
  "metformin": {
    displayName: "Metformin",
    benefits: [
      "Helps lower blood sugar levels in type 2 diabetes",
      "May reduce the risk of diabetes-related complications over time",
      "Does not typically cause weight gain, unlike some other diabetes medications"
    ],
    sideEffects: [
      "Nausea or upset stomach, especially when starting treatment",
      "Diarrhea",
      "Metallic taste in the mouth",
      "Rare: vitamin B12 deficiency with long-term use"
    ],
    seekHelpIf: "You experience unusual muscle pain, trouble breathing, or severe stomach pain — these can be signs of a rare but serious condition and need urgent attention."
  },
  "aspirin": {
    displayName: "Aspirin",
    benefits: [
      "Reduces pain, fever, and inflammation",
      "Low-dose aspirin can help prevent blood clots in some heart conditions"
    ],
    sideEffects: [
      "Stomach irritation or heartburn",
      "Increased bruising or bleeding",
      "Ringing in the ears at high doses"
    ],
    seekHelpIf: "You notice black or bloody stools, vomit that looks like coffee grounds, or signs of an allergic reaction (swelling, difficulty breathing)."
  },
  "atorvastatin": {
    displayName: "Atorvastatin",
    benefits: [
      "Lowers LDL (\"bad\") cholesterol",
      "Reduces the risk of heart attack and stroke over time"
    ],
    sideEffects: [
      "Muscle aches or weakness",
      "Joint pain",
      "Mild digestive upset"
    ],
    seekHelpIf: "You experience unexplained muscle pain, tenderness, or weakness — especially with fever or dark urine."
  },
  "lisinopril": {
    displayName: "Lisinopril",
    benefits: [
      "Lowers blood pressure",
      "Helps protect the kidneys in people with diabetes",
      "Reduces strain on the heart"
    ],
    sideEffects: [
      "Dry, persistent cough",
      "Dizziness, especially when standing up quickly",
      "Headache"
    ],
    seekHelpIf: "Your face, lips, or tongue swell, or you have trouble breathing — this can indicate a rare but serious allergic reaction."
  },
  "vitamin d": {
    displayName: "Vitamin D",
    benefits: [
      "Supports bone health and calcium absorption",
      "May support immune function",
      "Helps address deficiency-related fatigue"
    ],
    sideEffects: [
      "Generally well tolerated at recommended doses",
      "Very high doses over time may cause nausea or elevated calcium levels"
    ],
    seekHelpIf: "You experience persistent nausea, weakness, or confusion, which could indicate too much calcium in the blood."
  },
  "ibuprofen": {
    displayName: "Ibuprofen",
    benefits: [
      "Relieves pain and reduces inflammation",
      "Lowers fever"
    ],
    sideEffects: [
      "Stomach upset or heartburn",
      "Increased blood pressure with regular use",
      "Fluid retention"
    ],
    seekHelpIf: "You notice stomach pain with black stools, swelling, or shortness of breath."
  }
};

export const GENERIC_LEAFLET = {
  displayName: null,
  benefits: [
    "Taking this medication as prescribed helps it work the way your doctor intended",
    "Consistent timing helps keep the medication at a steady, effective level in your body"
  ],
  sideEffects: [
    "Side effects vary by medication — check the leaflet that came with your prescription, or ask your pharmacist",
    "Common general side effects can include mild stomach upset, drowsiness, or headache depending on the drug"
  ],
  seekHelpIf: "You experience anything severe or unexpected — difficulty breathing, swelling, a rash, chest pain, or anything that feels seriously wrong. Contact a doctor or pharmacist if you're ever unsure."
};

export function getMedicationInfo(name) {
  const key = name.trim().toLowerCase();
  if (MEDICATION_LIBRARY[key]) return MEDICATION_LIBRARY[key];
  // partial match fallback (e.g. "metformin 500mg")
  const found = Object.keys(MEDICATION_LIBRARY).find((k) => key.includes(k));
  if (found) return MEDICATION_LIBRARY[found];
  return { ...GENERIC_LEAFLET, displayName: name };
}
