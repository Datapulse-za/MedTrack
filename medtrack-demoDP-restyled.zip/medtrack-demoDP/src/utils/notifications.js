// Browser Notification API wrapper.
// Notifications only fire while this tab/app is open — a production build
// would use a service worker + push server for real background notifications.

export async function requestNotificationPermission() {
  if (!("Notification" in window)) return "unsupported";
  if (Notification.permission === "granted") return "granted";
  if (Notification.permission === "denied") return "denied";
  const result = await Notification.requestPermission();
  return result;
}

function fireNotification(title, body) {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  new Notification(title, { body, icon: undefined });
}

/**
 * Schedules a pre-reminder and an on-time reminder for the next occurrence
 * of `scheduledTime` (a "HH:MM" string, treated as a daily recurring dose time).
 * Returns the timer ids so they can be cancelled if needed.
 */
export function scheduleReminder(medicationName, scheduledTime, preReminderMinutes = 15) {
  const [hours, minutes] = scheduledTime.split(":").map(Number);
  const now = new Date();
  const next = new Date();
  next.setHours(hours, minutes, 0, 0);
  if (next.getTime() <= now.getTime()) {
    next.setDate(next.getDate() + 1); // next occurrence is tomorrow
  }

  const preReminderTime = new Date(next.getTime() - preReminderMinutes * 60 * 1000);

  const timers = [];

  const msUntilPre = preReminderTime.getTime() - now.getTime();
  if (msUntilPre > 0) {
    timers.push(
      setTimeout(() => {
        fireNotification(
          "Upcoming dose reminder",
          `${medicationName} is due in ${preReminderMinutes} minutes (${scheduledTime}).`
        );
      }, msUntilPre)
    );
  }

  const msUntilDose = next.getTime() - now.getTime();
  if (msUntilDose > 0) {
    timers.push(
      setTimeout(() => {
        fireNotification(
          "Time for your dose",
          `It's time to take ${medicationName}.`
        );
      }, msUntilDose)
    );
  }

  return { timers, nextDoseAt: next, preReminderAt: preReminderTime };
}

export function sendTestNotification(medicationName) {
  fireNotification("Test reminder", `This is what a reminder for ${medicationName} looks like.`);
}
