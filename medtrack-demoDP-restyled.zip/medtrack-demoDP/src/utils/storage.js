// Demo-only persistence via localStorage.
// In the full MedTrack build this is replaced by the Node/Express + SQLite backend.

const LOGS_KEY = "medtrack_demo_logs";
const MEDICATIONS_KEY = "medtrack_demo_medications";

export function loadLogs() {
  try {
    const raw = localStorage.getItem(LOGS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveLogs(logs) {
  localStorage.setItem(LOGS_KEY, JSON.stringify(logs));
}

export function loadMedications() {
  try {
    const raw = localStorage.getItem(MEDICATIONS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveMedications(medications) {
  localStorage.setItem(MEDICATIONS_KEY, JSON.stringify(medications));
}
