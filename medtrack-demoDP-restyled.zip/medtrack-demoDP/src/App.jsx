import React, { useEffect, useMemo, useState } from "react";
import Login from "./components/Login.jsx";
import TopNav from "./components/TopNav.jsx";
import StatsCards from "./components/StatsCards.jsx";
import TodaySchedule from "./components/TodaySchedule.jsx";
import WeekChart from "./components/WeekChart.jsx";
import MedicationsManager from "./components/MedicationsManager.jsx";
import ManualLogForm from "./components/ManualLogForm.jsx";
import LogHistory from "./components/LogHistory.jsx";
import RemindersPanel from "./components/RemindersPanel.jsx";
import CaregiverView from "./components/CaregiverView.jsx";
import Leaflet from "./components/Leaflet.jsx";
import { getMedicationInfo } from "./data/medications.js";
import { loadLogs, saveLogs, loadMedications, saveMedications } from "./utils/storage.js";
import {
  requestNotificationPermission,
  scheduleReminder,
  sendTestNotification,
} from "./utils/notifications.js";

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}
function nowTimeStr() {
  return new Date().toTimeString().slice(0, 5);
}
function isPastTime(time) {
  const [h, m] = time.split(":").map(Number);
  const now = new Date();
  const t = new Date();
  t.setHours(h, m, 0, 0);
  return t.getTime() < now.getTime();
}
function dateNDaysAgo(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
}

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [medications, setMedications] = useState([]);
  const [logs, setLogs] = useState([]);
  const [leafletInfo, setLeafletInfo] = useState(null);
  const [permission, setPermission] = useState(
    typeof Notification !== "undefined" ? Notification.permission : "unsupported"
  );
  const [reminders, setReminders] = useState([]);

  useEffect(() => {
    setMedications(loadMedications());
    setLogs(loadLogs());
  }, []);

  function handleLogin() {
    setIsLoggedIn(true);
  }

  async function handleRequestPermission() {
    const result = await requestNotificationPermission();
    setPermission(result);
  }

  // ---- Medications (recurring schedule) ----
  function handleAddMedication(med) {
    const updated = [...medications, med];
    setMedications(updated);
    saveMedications(updated);

    const { timers, nextDoseAt, preReminderAt } = scheduleReminder(med.name, med.time, 15);
    setReminders((prev) => [
      ...prev,
      { medicationId: med.id, medication: med.name, timers, nextDoseAt, preReminderAt },
    ]);
  }

  function handleRemoveMedication(id) {
    const updated = medications.filter((m) => m.id !== id);
    setMedications(updated);
    saveMedications(updated);

    setReminders((prev) => {
      const toRemove = prev.filter((r) => r.medicationId === id);
      toRemove.forEach((r) => r.timers.forEach((t) => clearTimeout(t)));
      return prev.filter((r) => r.medicationId !== id);
    });
  }

  // ---- Logging a dose (creates a log entry) ----
  function addLog(entry) {
    const updated = [...logs, entry];
    setLogs(updated);
    saveLogs(updated);
    if (entry.status !== "missed") {
      setLeafletInfo(getMedicationInfo(entry.medication));
    }
  }

  function handleMarkTaken(med) {
    addLog({
      medicationId: med.id,
      medication: med.name,
      dosage: med.dosage,
      scheduledTime: med.time,
      takenTime: nowTimeStr(),
      date: todayStr(),
      status: "taken",
      loggedAt: new Date().toISOString(),
    });
  }

  function handleMarkMissed(med) {
    addLog({
      medicationId: med.id,
      medication: med.name,
      dosage: med.dosage,
      scheduledTime: med.time,
      takenTime: "",
      date: todayStr(),
      status: "missed",
      loggedAt: new Date().toISOString(),
    });
  }

  function handleTestNotification(medicationName) {
    sendTestNotification(medicationName);
  }

  // ---- Derived: today's status per medication ----
  const statusByMedId = useMemo(() => {
    const map = {};
    logs
      .filter((l) => l.date === todayStr())
      .sort((a, b) => (a.loggedAt < b.loggedAt ? -1 : 1)) // last write wins
      .forEach((l) => {
        if (l.medicationId) map[l.medicationId] = l.status || "taken";
      });
    return map;
  }, [logs]);

  const takenTodayCount = useMemo(
    () => Object.values(statusByMedId).filter((s) => s === "taken").length,
    [statusByMedId]
  );

  // ---- Derived: 30-day adherence rate (% of expected doses actually taken) ----
  const adherenceRate30 = useMemo(() => {
    if (medications.length === 0) return 0;
    let expected = 0;
    let actual = 0;
    for (let i = 0; i < 30; i++) {
      const dateStr = dateNDaysAgo(i);
      const dayLogs = logs.filter((l) => l.date === dateStr);
      const distinctTaken = new Set(
        dayLogs.filter((l) => l.status === "taken").map((l) => l.medicationId).filter(Boolean)
      ).size;
      expected += medications.length;
      actual += Math.min(distinctTaken, medications.length);
    }
    return expected === 0 ? 0 : Math.round((actual / expected) * 100);
  }, [logs, medications]);

  const missedCount30 = useMemo(() => {
    const cutoff = dateNDaysAgo(29);
    return logs.filter((l) => l.status === "missed" && l.date >= cutoff).length;
  }, [logs]);

  const streak = useMemo(() => {
    const takenDates = new Set(logs.filter((l) => l.status === "taken").map((l) => l.date));
    let count = 0;
    for (let i = 0; i < 365; i++) {
      const dateStr = dateNDaysAgo(i);
      if (takenDates.has(dateStr)) {
        count++;
      } else if (i === 0) {
        continue; // today may not have a log yet — don't break streak on that alone
      } else {
        break;
      }
    }
    return count;
  }, [logs]);

  const alertCount = useMemo(
    () =>
      medications.filter(
        (m) => !statusByMedId[m.id] && isPastTime(m.time)
      ).length,
    [medications, statusByMedId]
  );

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-cream">
      <TopNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onSignOut={() => setIsLoggedIn(false)}
        alertCount={alertCount}
      />

      <main className="max-w-5xl mx-auto px-4 py-8 space-y-6">
        {activeTab === "dashboard" && (
          <>
            <StatsCards
              medications={medications}
              takenTodayCount={takenTodayCount}
              adherenceRate30={adherenceRate30}
              missedCount30={missedCount30}
              streak={streak}
            />
            <div className="grid gap-6 lg:grid-cols-3">
              <div className="lg:col-span-2 space-y-6">
                <TodaySchedule
                  medications={medications}
                  statusByMedId={statusByMedId}
                  onMarkTaken={handleMarkTaken}
                  onMarkMissed={handleMarkMissed}
                />
                <WeekChart logs={logs} medications={medications} />
              </div>
              <div>
                <RemindersPanel
                  permission={permission}
                  onRequestPermission={handleRequestPermission}
                  reminders={reminders}
                  onTestNotification={handleTestNotification}
                />
              </div>
            </div>
          </>
        )}

        {activeTab === "medications" && (
          <MedicationsManager
            medications={medications}
            onAdd={handleAddMedication}
            onRemove={handleRemoveMedication}
          />
        )}

        {activeTab === "history" && (
          <div className="space-y-6">
            <ManualLogForm medications={medications} onLog={addLog} />
            <LogHistory
              logs={logs}
              onViewLeaflet={(medName) => setLeafletInfo(getMedicationInfo(medName))}
            />
          </div>
        )}

        {activeTab === "caregiver" && (
          <CaregiverView
            medications={medications}
            logs={logs}
            statusByMedId={statusByMedId}
            adherenceRate30={adherenceRate30}
            streak={streak}
          />
        )}
      </main>

      <Leaflet info={leafletInfo} onClose={() => setLeafletInfo(null)} />
    </div>
  );
}
