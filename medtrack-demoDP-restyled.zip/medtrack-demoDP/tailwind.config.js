/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        display: ['Manrope', 'sans-serif'],
      },
      colors: {
        navy: '#0f1b3d',
        'blue-deep': '#14318c',
        brand: '#2563eb',
        // MedTrack UI palette — matched to the mobile design reference
        gold: '#C77F1E',
        cream: '#F7F5EF',
        teal: {
          DEFAULT: '#157A72',
          50: '#E1F0EC',
          100: '#CDE7E0',
          200: '#9FCFC4',
          600: '#178074',
          700: '#157A72',
          800: '#0B4A46',
        },
        amber: {
          50: '#FBEDD4',
          100: '#FBEDD4',
          200: '#F5D9A8',
          300: '#F0C67C',
          400: '#E8A33D',
          500: '#E8A33D',
          600: '#C77F1E',
          700: '#C77F1E',
          800: '#9C6416',
        },
        red: {
          50: '#F5E4EB',
          100: '#F5E4EB',
          400: '#B85A7C',
          500: '#A04068',
          600: '#92395C',
          700: '#7A2E4C',
        },
        gray: {
          50: '#F7F5EF',
          100: '#EEEDE6',
          200: '#E7E2D6',
          300: '#D7D2C4',
          400: '#B9BDB4',
          500: '#8B9089',
          700: '#4B5650',
          800: '#28352F',
          900: '#14231F',
        },
        amber2: '#E8A33D',
      },
      borderRadius: {
        lg: '0.75rem',
        xl: '1rem',
        '2xl': '1.25rem',
      },
    },
  },
  plugins: [],
}
