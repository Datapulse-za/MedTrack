# MedTrack — Medication Adherence Demo

A demo build of MedTrack: manage recurring medications with instructions,
track daily doses as **taken or missed**, see a leaflet of benefits/side
effects after each log, get browser notifications for upcoming doses, and
check adherence from a **caregiver view** — directly reflecting the gaps
identified in the project's research (basic alarms with no medication
detail, no taken/missed tracking, limited caregiver support).

This is a **frontend-only demo** — no backend, no real user accounts.
Data is stored in the browser's localStorage, so it resets if you clear
site data, and does not sync across devices/browsers.

## Demo login (hardcoded)

There is no real authentication. These credentials are hardcoded in
`src/components/Login.jsx` and are the only ones that work:

```
Username: demo
Password: medtrack2026
```

Give these to anyone who needs to log in for a demo.

## Running it locally

```bash
npm install
npm run dev
```

Then open the URL it prints (usually `http://localhost:5173`).

## Building for deployment (e.g. Netlify)

```bash
npm run build
```

This outputs a static `dist/` folder — drag that folder onto
[app.netlify.com/drop](https://app.netlify.com/drop), or point a
Netlify site at this repo with build command `npm run build` and
publish directory `dist`.

## Features

- **Dashboard tab** — stats cards for doses taken today, **30-day
  adherence rate** (the same measurement cited in the project's research
  as the standard used in the StAR trial), missed-dose count, current
  streak, and medications tracked. Below that: today's schedule with
  one-tap "mark taken" / "mark missed," a 7-day adherence bar chart, and
  the reminders panel. An amber "N due" badge appears in the header when
  scheduled doses are overdue and unlogged.
- **Medications tab** — add or remove medications with name, dosage,
  daily scheduled time, and free-text instructions (e.g. "take with
  food"). Adding one automatically schedules its reminder.
- **History tab** — a manual log form for logging today's dose,
  backfilling an earlier one, or recording a dose as missed — plus a
  searchable, day-grouped log with a Taken/Missed badge on every entry.
- **Caregiver view tab** — the feature the research specifically calls
  out as missing from most existing solutions: a read-only summary
  showing 30-day adherence, current streak, today's per-medication
  status (taken/missed/pending), and a list of recent missed doses, so
  a caregiver can check in without tracking every dose themselves.
- **Leaflet** — logging a dose as taken opens a modal with benefits and
  possible side effects for that medication, pulled from a small local
  dataset (`src/data/medications.js`). Unrecognized medication names
  fall back to a generic leaflet. **This data is for demo purposes
  only** — it is not a verified medical source.
- **Notifications** — on adding a medication, the app requests browser
  notification permission and schedules two notifications for the
  *next* occurrence of its scheduled time: a pre-reminder (15 minutes
  before, configurable in `src/utils/notifications.js`) and an on-time
  reminder. Each also has a "send test notification now" button so you
  don't have to wait for the real time to demo it.

## Known limitations (demo scope)

- Notifications only fire while the browser tab is open — a production
  version would need a service worker + push server for background
  notifications.
- The medication info leaflet is a small hardcoded dataset, not a live
  medical database.
- No real backend — data is per-browser via localStorage, not shared
  between users, devices, or an actual separate caregiver account. The
  Caregiver tab shows the same demo patient's data rather than a truly
  separate login — the full build would need a second role/account tied
  to the Node/Express/SQLite backend.
- Missed doses only exist when explicitly logged (via "Mark missed" or
  the manual log form) — the app does not yet auto-flag a dose as
  missed purely from time passing, though the adherence-rate
  calculation already treats any unlogged expected dose as not taken.
- Streak counts any day with at least one dose logged as taken, not
  full-day adherence — simple by design for a demo.
- Single hardcoded login only — no multi-user support.
